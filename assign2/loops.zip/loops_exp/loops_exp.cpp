#include <iostream> 	// Allows input output operations
#include <iomanip>		// Allows usage of setprecision
#include <math.h>		/* exp */

using namespace std;

int main() {

	/*********** DO NOT CHANGE VARIABLE NAMES ************/
	unsigned int k = 1;	//Keeps track of the count in the loop
	double ex = 1; 		//The summation of each polynomial evaluated
	double err;			//Err
	double x;		 	//Input


	/***************Get User Input***************/
	cout << "x = ";
	cin >> x;
	cout << endl;

	cout << "Error = ";
	cin >> err;
	cout << endl;

	/***************End User Input***************/	
	

	/*---------------------------------------------*/
	// Please add your code here for Q1





	/*---------------------------------------------*/

	cout << "exp(" << x << ") = " << setprecision(7) <<  ex << endl;
	cout << "Number of Terms : " << k << endl;

	return 0;
}
