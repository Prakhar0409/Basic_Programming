#include <iostream> 	// Allows input output operations
using namespace std;

int main() {

	int N;
	cout << "N=";
	cin >> N;
	cout << endl;

	/*---------------------------------------------*/
	// Add your code here for Q3
	
	// 
	/*---------------------------------------------*/

	return 0;
}
