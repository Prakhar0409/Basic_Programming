#include <iostream> 	// Allows input output operations
#include <iomanip>		// Allows usage of setprecision
#include <math.h>		/* exp */

using namespace std;


int main() {

	/*********** DO NOT CHANGE VARIABLE NAMES ************/
	int array[100];	    //  Input Array entered by the user
	int N ;             //  Number of elements, N <=100

        int len =0;
        int start = 0;

	/***************Get User Input***************/
	cout << "Enter number of elements ";
	cin >> N;
	cout << endl;

	cout << "Enter " << N << " integers ";
	cout << endl;

        //Taking input in array  
        for(int i = 0; i < N; i++){
          cin>>array[i];        
        }
        cout<<endl; 

	/***************End User Input***************/	
	
	
	/*---------------------------------------------*/
	// Please add your code here for Q1
        

        /*---------------------------------------------*/

        for(int j = start; j< (len + start); j++)
           cout<<array[j]<<" ";
        cout<<endl;
           
        cout<<"Start  =  " << start<<endl;
        cout<<"Length =  " << len<<endl;
	
	return 0;
}
